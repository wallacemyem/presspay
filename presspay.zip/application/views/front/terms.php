<?php $this->load->view('front/sub/header') ?>
</head>


  </head>
  <body>
    <div class="ie-panel">
      
    </div>
    <div class="page">
      <!-- Page Header-->
      <?php $this->load->view('front/sub/menu') ?>
      <section class="section section-overlap bg-decorate bg-banner1 bg-banner-small">
      </section>
      <section class="section section-overlap bg-decorate bg-banner1 bg-banner-small">
        <div class="section-overlap-content">
          <div class="container pt-0">
              <div class="row">
                <div class="col-md-7 col-lg-7 col-xl-7">
                  <h1 class="wow-outer">
                    <span class="font-weight-bold wow-outer">
                      <span class="wow slideInUp" data-wow-delay="1.5s">Terms of Service.</span>
                    </span>
                    <p class="font-weight-exlight-p wow-outer">
                      <span class="wow slideInUp" data-wow-delay="3.1s">
                      </span>
                    </p>
                  </h1>
                </div>
              </div>
          </div>
        </div>
      </section>
      <section id="refer" class="section bg-gray-100">
        <div class="range justify-content-xl-between">
          <div class="cell-xl-6 align-self-center container">
            <div class="row">
              <div class="col-lg-9 cell-inner">
                <div class="section-lg">
                  <p class="wow-outer"><span class="wow slideInDown">Coming soon</span></p>
                </div>
              </div>
            </div>
          </div>
          <div class="cell-xl-5 height-fill wow fadeIn">
            
          </div>
        </div>
      </section>
      <!-- Page Footer-->
        <?php $this->load->view('front/sub/footer') ?>
        <?php $this->load->view('front/sub/footerscripts') ?>
    </div>
  </body>
</html>