<!DOCTYPE html>
<html>
<head>
	<title>Codeigniter 3 - Generate PDF from view using dompdf library with example</title>
</head>
<body>


<h1>Codeigniter 3 - Generate PDF from view using dompdf library with example</h1>
<table style="border:1px solid red;width:100%;">
	<tr>
		<th style="border:1px solid red">Id</th>
		<th style="border:1px solid red">Name</th>
		<th style="border:1px solid red">Email</th>
	</tr>
	<tr>
		<td style="border:1px solid red">1</td>
		<td style="border:1px solid red">Jhon</td>
		<td style="border:1px solid red">jhon@gmail.com</td>
	</tr>
	<tr>
		<td style="border:1px solid red">2</td>
		<td style="border:1px solid red">Lucy</td>
		<td style="border:1px solid red">lucy@gmail.com</td>
	</tr>
</table>


</body>
</html>