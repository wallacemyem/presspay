<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pdf extends CI_Controller {

}

/* End of file example.php */
/* Location: ./application/controllers/example.php */