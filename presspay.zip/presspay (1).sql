-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 29, 2021 at 08:55 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `presspay`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `last_seen` datetime DEFAULT NULL,
  `ip_address` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `dob` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cms`
--

CREATE TABLE `tbl_cms` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sub_name` varchar(100) DEFAULT NULL,
  `value` text NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `last_updated` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cms`
--

INSERT INTO `tbl_cms` (`id`, `name`, `sub_name`, `value`, `icon`, `created_date`, `last_updated`) VALUES
(34, 'why', 'Easy Access', 'We offer you student loan as against what is obtainable with other financial institutions and platforms', 'onboard.svg', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(35, 'why', 'Fee Co-Funding', 'We co-fund your tuition year after year till you graduate', 'credit.svg', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(36, 'why', 'Flexible Loans', 'Flexible student loan application and repayment process.', 'collateral.svg', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(37, 'why', 'Scholarships', 'Enjoy our scholarship pop-ups and education grants ', 'cc.svg', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(38, 'why', 'Moderate Interest', 'We offer you student loan at a moderate interest rate', 'flexible.svg', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(39, 'why', 'Make Money', 'Make money while looking for money; income opportunities from referrals', 'credit.svg', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(40, 'feed', 'Angela Philips', 'Easy and simple to use. Great job!', 'f1.png', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(41, 'feed', 'John Doe', 'This is a good innovation', 'f2.png', '2021-06-12 23:32:05', '2021-06-12 23:32:05'),
(42, 'feed', 'Smart John', 'This will go a long way in helping several students complete their education', 'f3.png', '2021-06-12 23:32:05', '2021-06-12 23:32:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faqs`
--

CREATE TABLE `tbl_faqs` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `descr` text NOT NULL,
  `type` enum('student','uni','model','phil') NOT NULL DEFAULT 'student'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_faqs`
--

INSERT INTO `tbl_faqs` (`id`, `title`, `descr`, `type`) VALUES
(1, 'How do I apply for a loan or co-funding?', 'You can apply for a loan or co-funding by following the steps below \r\n\r\nSTEP 1: Download the PressPayNG app on your google play store or app store.\r\nSTEP 2: OPEN THE APP, REGISTER AND APPLY', 'student'),
(2, 'Do I need to be admitted before I can apply for the loan at a particular university?', 'Yes, you do. for fresh students, you must have paid you acceptance fee to be eligible for the loan', 'student'),
(3, 'What are the basic requirements for the co-founding', '1. Register on the platform with accurate information\r\n2. On-board with a Sponsor\r\n3.  On-board with 2 Academic Role Models (Lecturers)', 'student'),
(4, 'Why should I summit my school record?', 'Your school record is part of our KYC requirements', 'student'),
(5, 'Do I have to reapply for the loan every year?', 'Yes', 'student'),
(6, 'How much am I entitled to and for how long?', 'You are entitled to up to 50% of your tuition fee', 'student'),
(7, 'Can I apply for an amount higher than what am shown?', 'The amount you are shown is based on your school tuition fee', 'student'),
(8, 'How does your savings work?', 'We have different savings plan and offer, register or log into the PressPayNG app if you are already an existing user to see which is suitable for you.', 'student'),
(9, 'Do I need to provide collateral to request for co-funding or a loan?', 'No, you do not need to provide a collateral', 'student'),
(10, 'Can I request and access PressPayNG services anywhere in Nigeria?', 'PressPayNG app is available and accessible everywhere in Nigeria.', 'student'),
(11, 'I have shared all information required, when am I granted my request?', 'You can get credited in 48 hours and commence your savings to balance up the payment of your tuition', 'student'),
(12, 'What happens when a student default?', 'PressPayNg has an arrangement with the school to deal with issues of default', 'student'),
(13, 'How can I keep records of my savings and loans?', 'The PressPayNG app enables you to track your financial records, statements, receipts and deposit', 'student'),
(14, 'Do I need to summit my bank details?', 'Yes, there is a need for your bank details as part of the onboarding process', 'student'),
(15, 'How do I earn rewards?', 'You earn rewards by referral bonus', 'student'),
(16, 'Why do parents or guardians have to provide their information if the child is 18 years old?', 'It\'s part of the application requirements and KYC ', 'student'),
(17, 'Are there other extra or hidden charges to getting co-fund loan from PressPayNG?', 'Yes, just a moderate interest rate with admin charges', 'student'),
(18, 'What is your policy towards renewing your contract with PressPayNg?', 'Zero outstanding debt or default ', 'student'),
(19, 'What is your policy towards terminating your contract with PressPayNg?', 'Please check our terms and conditions', 'student'),
(20, 'What are your options on how to repay a loan?', 'You can visit the PressPayNG website or log into the app to see the repayment plans.', 'student'),
(21, 'How is the co-funding or loan sent?', 'The co-funding or loan is payed directly into the institution account on behalf of the student', 'student'),
(22, 'What if I had an income reduction or lost my job after filling and summitting my Childs co-funding or loan request?', 'Please reach out to our customer care', 'student'),
(23, 'What is the role of the institution?', 'To provide institutional support for co-funding the tuition of their students', 'uni'),
(24, 'How can we get affiliated?', 'An institution can get affiliated by onboarding the app and also liaising with our customer care.', 'uni'),
(25, 'How do we upload students records?', 'Student records can be uploaded through the PressPayNG app', 'uni'),
(26, 'How will expressions of interest be assessed?', 'By engaging our customer care team', 'uni'),
(27, 'Who is an academic role model? ', 'An academic role model is a person who a student looks up to academically to help attain academic goals and achievement', 'model'),
(28, 'How many academic role models are required to facilitate tuition loan?', 'Two', 'model'),
(29, 'What is required of me?', 'To confirm that you are aware of the student’s application for loan and would provided the needed support in facilitating the loan and its repayment', 'model'),
(30, 'What document do I need to provide?', 'Personal information', 'model'),
(31, 'Do I need to provide my financial statement?', 'No', 'model'),
(32, 'Are my bank details required?', 'No', 'model'),
(33, 'What are the associated risks of being an academic role model to an applicant?', 'The basic requirement to become an academic role model are:\r\n1. Must be an academic member of staff in the same institution of the applicant', 'model'),
(34, 'How do I stop being an academic role model?', 'You can stop being an academic role model by informing the student and a change is effected on the student’s profile', 'model'),
(35, 'Can I be an academic role model for more than one person?', 'YES, you can!', 'model'),
(36, 'How do I sponsor students on your platform?', 'Ask the student to download and register on the app. A tuition savings/payment link can be generated by the applicant and sent to you to credit the app directly as against giving the student cash or crediting personal accounts. you can bank on PressPayNG to ensure that all donations to a student will be credited to the institution directly.\r\n  \r\nPressPayNG bridges the trust deficit between students and philanthropist/sponsor. no scam, no games, no diversion of fund. we fund the future', 'phil');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `descr` text NOT NULL,
  `image` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payments`
--

CREATE TABLE `tbl_payments` (
  `id` int(11) NOT NULL,
  `amount_paid` float NOT NULL,
  `total_amount` float NOT NULL,
  `course_id` int(11) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `reference_no` varchar(100) NOT NULL,
  `paid_by` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `email` varchar(100) NOT NULL,
  `uid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_referal`
--

CREATE TABLE `tbl_referal` (
  `id` int(11) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `remail` varchar(100) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `femail` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_referal`
--

INSERT INTO `tbl_referal` (`id`, `rname`, `remail`, `fname`, `femail`, `created_date`) VALUES
(2, 'Timothy Afolabi', 'timothy.programmer@gmail.com', 'Timothy', 'test@test.com', '2021-06-29 11:37:30'),
(3, 'Timothy Afolabi', 'timothy.programmer@gmail.com', 'Timothy', 'test@test.com', '2021-06-29 11:50:57'),
(4, 'Timothy Afolabi', 'timothy.programmer@gmail.com', 'Timothy', 'tumim@hotmail.co.uk', '2021-07-07 10:20:48'),
(5, 'Mary Shadrack', 'mary@gmail.com', 'Timothy Afolabi', 'timothy.programmer@gmail.com', '2021-07-07 10:25:33'),
(6, '', 'mary@gmail.com', 'Timothy Afolabi', 'timothy@gmai.co', '2021-07-07 23:50:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reset`
--

CREATE TABLE `tbl_reset` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `code` varchar(6) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE `tbl_resource` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `name`, `value`) VALUES
(1, 'pkTest', 'pk_test_de6148ff9b35639c894b30c7369301d06ceff2b0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sliders`
--

CREATE TABLE `tbl_sliders` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `descr` text NOT NULL,
  `image` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_cms`
--
ALTER TABLE `tbl_cms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_faqs`
--
ALTER TABLE `tbl_faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payments`
--
ALTER TABLE `tbl_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `tbl_referal`
--
ALTER TABLE `tbl_referal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reset`
--
ALTER TABLE `tbl_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sliders`
--
ALTER TABLE `tbl_sliders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_cms`
--
ALTER TABLE `tbl_cms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tbl_faqs`
--
ALTER TABLE `tbl_faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_payments`
--
ALTER TABLE `tbl_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_referal`
--
ALTER TABLE `tbl_referal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_reset`
--
ALTER TABLE `tbl_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_sliders`
--
ALTER TABLE `tbl_sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
